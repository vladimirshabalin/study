<?php

$a = 1;
$b = 2;

$a=$a+$b-$b=$a;

echo $a;
echo '<br>';
echo $b;